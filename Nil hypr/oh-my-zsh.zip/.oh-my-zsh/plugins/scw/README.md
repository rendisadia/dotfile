## Scaleway CLI plugin

This plugin adds completion for [scw](https://github.com/scaleway/scaleway-cli), the command line interface for Scaleway.

To use it, add `scw` to the plugins array in your zshrc file:

```zsh
plugins=(... scw)
```
